ACTIVITY DIARY - GITHUB PAGES SETUP

1. Extract this ZIP on a computer.
2. Open https://github.com/mayureshkikle-netizen/activity-diary
3. Choose Add file > Upload files.
4. Upload ALL five files from this folder (index.html, manifest.webmanifest, sw.js, icon-192.png, icon-512.png). README.txt is optional.
5. Commit changes to the main branch.
6. Open repository Settings > Pages.
7. Under Build and deployment, choose Deploy from a branch.
8. Select branch main and folder /(root), then Save.
9. Wait a few minutes. The app address will be:
   https://mayureshkikle-netizen.github.io/activity-diary/
10. Open that address in Chrome on the Android phone, tap the three-dot menu, then Install app (or Add to Home screen).

IMPORTANT: Activity entries are saved in this browser's local storage on this phone. They are not synced to GitHub or other devices. Export the monthly CSV regularly for backup. Clearing browser site data can erase entries.
